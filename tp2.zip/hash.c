#include "hash.h"
#include "lista.h"
#define CAPACIDAD_INICIAL 50
#define FACTOR_DE_RED 7
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>

/******************************
	Estructuras del codigo		
******************************/

typedef struct campo{
	char* clave_h;
	void* valor;
}campo_t;


typedef struct nodo{
	campo_t* campo;
	struct nodo* prox;
} nodo_t;

struct hash{
	size_t cantidad;
	int capacidad;
	lista_t** tabla;
	hash_destruir_dato_t f_destruir;
};

struct hash_iter{
	const hash_t* hash;
	int posicion_tabla;
	lista_iter_t* nodo;
};

/*********************************
			FUNCIONES
*********************************/

int hashf(const char *word) {
        int hash = 5381;
        int c;
        c = *word++;
        while (c != '\0'){

            hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
        	c = *word++;
        }

        return hash;
    }

hash_t* hash_crear(hash_destruir_dato_t destruir_dato){
	hash_t* hash = malloc(sizeof(hash_t));
	hash->tabla = malloc(sizeof(lista_t*) * CAPACIDAD_INICIAL);
	hash->capacidad = CAPACIDAD_INICIAL;
	for (int i = 0; i < CAPACIDAD_INICIAL; ++i)
	{
		hash->tabla[i] = NULL;
	}
	hash->cantidad = 0;
	hash->f_destruir = destruir_dato;
	return hash;
}

campo_t* campo_crear(void* dato, char* clave){
	campo_t* campo = malloc(sizeof(campo_t));
	if (campo==NULL){
		return NULL;
	}
	campo->valor = dato;
	campo->clave_h = clave;
	return campo;
}	

void* caso_const(lista_iter_t* iter){
	const lista_iter_t* iter_aux = iter;
	return lista_iter_ver_actual(iter_aux);
}

campo_t* buscar_nodo(const hash_t* hash, const char* clave, void* caso(lista_iter_t* iter), int posicion){
	lista_iter_t* iter = lista_iter_crear(hash->tabla[posicion]);
	while(!lista_iter_al_final(iter) && strcmp(((campo_t*)lista_iter_ver_actual(iter))->clave_h, clave)!=0){
		lista_iter_avanzar(iter); 
	}
	campo_t* campo = (campo_t*)caso(iter);
	lista_iter_destruir(iter);
	return campo;
}


bool hash_pertenece(const hash_t *hash, const char *clave){
	int posicion = hashf(clave);
	posicion = abs(posicion % hash->capacidad);
	if(strlen(clave)== 0){
		posicion = 0;
	}
	if(hash->tabla[posicion] == NULL){
		return NULL;
	}
	campo_t* campo = buscar_nodo(hash, clave, caso_const, posicion);
	if(campo==NULL){
		return false;
	}
	return true;
}

bool hash_redimensionar(hash_t* hash){
    campo_t* campo;
    lista_t** nueva_tabla = malloc(sizeof(lista_t*) * (size_t)(hash->capacidad * FACTOR_DE_RED));
    if (nueva_tabla == NULL) return false;
    for (int i = 0; i < hash->capacidad * FACTOR_DE_RED; ++i)
    {
        nueva_tabla[i] = NULL;
    }
    int cap_ant = hash->capacidad;
    lista_t** tabla_ant = hash->tabla;
    hash->tabla = nueva_tabla;
    hash->capacidad = (hash->capacidad * FACTOR_DE_RED);
    bool no_falla = true;
    for (int i = 0; i < cap_ant; ++i){
        lista_t* lista_act = tabla_ant[i];
        if(lista_act==NULL){
            continue;
        }
        lista_iter_t* iter = lista_iter_crear(lista_act);
        while(!lista_iter_al_final(iter)){
        	campo = lista_iter_ver_actual(iter);
        	hash->cantidad--;
			no_falla = hash_guardar(hash, campo->clave_h, campo->valor);
			lista_iter_avanzar(iter);
			if (!no_falla){
        		free(nueva_tabla);
        		hash->tabla = tabla_ant;
        		hash->capacidad = cap_ant;
        		lista_iter_destruir(iter); 
        		return false;
    		}   
			free(campo->clave_h);
			free(campo);
		}
		lista_iter_destruir(iter); 
    }
    for(int i=0; i< cap_ant; i++){
        if(tabla_ant[i] != NULL) lista_destruir(tabla_ant[i], NULL);
    }
    free(tabla_ant);
    return true;
}       

int pos(const char* clave, const hash_t* hash){
	int posicion = hashf(clave);
	posicion =  abs(posicion % hash->capacidad);
	if(strlen(clave)== 0){
		posicion = 0;
	}
	return posicion;
}

campo_t* obtener(const hash_t* hash, const char* clave, void* caso(lista_iter_t* iter)){
	int posicion = pos(clave, hash);
	if(hash->tabla[posicion] == NULL){
		return NULL;
	}
	campo_t* campo = buscar_nodo(hash, clave, caso, posicion);
	if(campo==NULL){
		return NULL;
	}
	if(lista_esta_vacia(hash->tabla[posicion])){
		lista_t* a_borrar = hash->tabla[posicion];
		hash->tabla[posicion] = NULL;
		free(a_borrar);
	}
	return campo;
}

bool hash_guardar(hash_t* hash, const char* clave, void* dato){
	campo_t* campo = NULL;
	if (hash->cantidad > (hash->capacidad)* 4){
		if(!hash_redimensionar(hash)) return false;
	}
	int posicion = pos(clave, hash);
	if(hash->tabla[posicion] == NULL){
		lista_t* lista = lista_crear();
		if(!lista){
			return false;
		}
		hash->tabla[posicion] = lista;
	}
	campo = buscar_nodo(hash, clave, caso_const, posicion);
	if(campo){
		void* a_borrar = campo->valor;
		campo->valor = dato;
		hash_destruir_dato_t liberar = hash->f_destruir;
		if(hash->f_destruir != NULL){
			liberar(a_borrar);
		}
		return true;
	}
	char* clave2 = malloc(sizeof(char) * (strlen(clave)+ 1));
	strcpy(clave2, clave);
	campo = campo_crear(dato, clave2);
	if (campo == NULL){
		free(clave2);
		return false;
	}
	bool resultado = lista_insertar_ultimo(hash->tabla[posicion], campo);
	if(resultado==false){
		return resultado;
	}
	hash->cantidad++;
	return true;
}

void *hash_obtener(const hash_t *hash, const char *clave){
	campo_t* campo = obtener(hash, clave, caso_const);
	if(campo==NULL){
		return NULL;
	}
	return campo->valor;
}

void* hash_borrar(hash_t* hash, const char* clave){
	campo_t* campo = obtener(hash, clave, lista_iter_borrar);
	if(campo==NULL){
		return NULL;
	}
	void* dato = campo->valor;
	free(campo->clave_h);
	free(campo);
	hash->cantidad--;
	return dato;
}	
	
size_t hash_cantidad(const hash_t *hash){
	return hash->cantidad;
}

void hash_destruir(hash_t *hash){
	for(int i=0; i< hash->capacidad; i++){
		while(hash->tabla[i] != NULL && !lista_esta_vacia(hash->tabla[i])){
			campo_t* campo=lista_borrar_primero(hash->tabla[i]);
			free(campo->clave_h);
			hash_destruir_dato_t liberar = hash->f_destruir;
			if (liberar != NULL){
				liberar(campo->valor);	
			}
			free(campo);
			if (lista_esta_vacia(hash->tabla[i])){
				lista_destruir(hash->tabla[i], NULL);
				break;
			}
		}
	}
	free(hash->tabla);
	free(hash);
}
	
	
	
/*********************************
	ITERADOR DEL HASH
*********************************/
hash_iter_t *hash_iter_crear(const hash_t *hash){
	hash_iter_t* hash_iter = malloc(sizeof(hash_iter_t));
	if (hash_iter == NULL)
	{
		return NULL;
	}
	hash_iter->hash = hash;
	hash_iter->posicion_tabla = 0;
	while(hash->tabla[hash_iter->posicion_tabla]==NULL){
		if(hash_iter->posicion_tabla == hash_iter->hash->capacidad-1){
			hash_iter->nodo = NULL;
			return hash_iter;
		}
		hash_iter->posicion_tabla++;
	}
	hash_iter->nodo = lista_iter_crear(hash->tabla[hash_iter->posicion_tabla]);
	return hash_iter;
}

bool hash_iter_al_final(const hash_iter_t *iter){
	return (iter->hash->cantidad==0||(lista_iter_al_final(iter->nodo) && iter->posicion_tabla == iter->hash->capacidad-1));
}

bool hash_iter_avanzar(hash_iter_t *iter){
	/*while(iter->hash->tabla[iter->posicion_tabla]==NULL || lista_iter_ver_actual(iter->nodo)==NULL){
		if(iter->posicion_tabla == iter->hash->capacidad-1 && hash_iter_al_final(iter)){
			return false;
		}
		iter->posicion_tabla++;	
	}
	if(iter->nodo==NULL){
			iter->nodo = lista_iter_crear(iter->hash->tabla[iter->posicion_tabla]);
		return true;
	}	
	if (lista_iter_al_final(iter->nodo));
	{
		lista_iter_destruir(iter->nodo);
		return hash_iter_avanzar(iter);
	}
	lista_iter_avanzar(iter->nodo);
	return true;*/
	if ((iter->nodo)==NULL)
	{
		return false;
	}
	if(lista_iter_avanzar(iter->nodo)==false || lista_iter_al_final(iter->nodo)){
		if (iter->posicion_tabla==iter->hash->capacidad-1)
		{
			return false;
		}
		iter->posicion_tabla++;
		while(iter->hash->tabla[iter->posicion_tabla]==NULL){
			if(hash_iter_al_final(iter)){
				return false;
			}
			iter->posicion_tabla++;
		}
		lista_iter_destruir(iter->nodo); 
		iter->nodo = lista_iter_crear(iter->hash->tabla[iter->posicion_tabla]);
	}
	//if(lista_iter_al_final(iter->nodo)){
	//	return hash_iter_avanzar(iter);
	//}
	return true;
}



const char *hash_iter_ver_actual(const hash_iter_t *iter){
	if(hash_iter_al_final(iter) || iter->nodo == NULL){
		return NULL;
	}
	campo_t* campo = lista_iter_ver_actual(iter->nodo);
	if (campo == NULL)
	{
		printf("%s\n", "NULL");
		//return "1";
	}
	return campo->clave_h;
}	
	


void hash_iter_destruir(hash_iter_t* iter){
	if(iter->nodo != NULL){
		lista_iter_destruir(iter->nodo);
	}
	free(iter);
}
