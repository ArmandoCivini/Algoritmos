#define _GNU_SOURCE
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "strutil.h"
#include "abb.h"
#include "hash.h"
#include "pila.h"
#include "cola.h"
#include "heap.h"
#include "lista.h"
#define N 5
#define RED 2

typedef struct vuelos{
	abb_t* arbol;
	hash_t* hash;
}vuelos_t;

typedef struct vuelo{
	char** datos_separados;
}vuelo_t;

vuelo_t* vuelo_crear(char** separados){
	vuelo_t* vuelo = malloc(sizeof(vuelo_t));
	vuelo->datos_separados = separados;
	return vuelo;
	
}

void vuelo_destruir(void* vuelo){
	free_strv(((vuelo_t*)vuelo)->datos_separados);
	free(vuelo);
}

void borrar_del_abb(abb_t* abb, char** conjun){
	lista_t* lista = abb_obtener(abb, conjun[6]);
	lista_iter_t* iter = lista_iter_crear(lista);
	vuelo_t* actual = lista_iter_ver_actual(iter);
	while(strcmp(actual->datos_separados[0], conjun[0])!=0){
		lista_iter_avanzar(iter);
		actual = lista_iter_ver_actual(iter);
	}
	vuelo_t* anterior = lista_iter_borrar(iter);
	vuelo_destruir(anterior);
	lista_iter_destruir(iter);
}

void destruir_dato_abb(void* lista){
	lista_destruir((lista_t*)lista, vuelo_destruir);
}

bool agregar_archivo(char* arch, vuelos_t* vuelos){
	//char* linea = NULL;
	size_t capacidad = 0;
	FILE* archivo = fopen(arch, "r");
	if (archivo == NULL){
		printf("%s\n", "aca");
		return false;
	}
	char* linea = NULL;
	while(!feof(archivo)){
		ssize_t largo = getline(&linea, &capacidad, archivo);
		if(largo < 0){
			continue;
		}
		char** conjun_aux = split(linea, ',');
		vuelo_t* vuelo = vuelo_crear(conjun_aux);
		vuelo_t* resultado_h = hash_obtener(vuelos->hash, conjun_aux[0]);
		if(resultado_h){
			borrar_del_abb(vuelos->arbol, conjun_aux);
		}
		printf("%s\n", conjun_aux[0]);
		if (!hash_guardar(vuelos->hash, conjun_aux[0], vuelo)) return false;
		lista_t* resultado_l = abb_obtener(vuelos->arbol, conjun_aux[6]);
		if(resultado_l){
			printf("%s\n", "fecha repetida");
			lista_insertar_primero(resultado_l, vuelo);
		}else{
			lista_t* lista = lista_crear();
			lista_insertar_primero(lista, vuelo);
			if(!abb_guardar(vuelos->arbol, conjun_aux[6], lista)){
				lista_destruir(lista, NULL);
				fclose(archivo);
				printf("%s\n", "abb_guardar");
				return false;
			}
		}
	}
	free(linea);
	fclose(archivo);
	return true;
}

void print_error_o_OK(bool ok, char* comando_error){
	if (ok){
		printf("OK\n");
		return;
	}
	fprintf( stderr, "Error en comando %s\n", comando_error);
}

void print_error(char* comando_error){
	fprintf( stderr, "Error en comando %s\n", comando_error);
}

vuelos_t* crear_vuelos(){
	vuelos_t* vuelos = malloc(sizeof(vuelos_t));
	vuelos->arbol = abb_crear(strcmp, destruir_dato_abb);
	vuelos->hash = hash_crear(vuelo_destruir);
	return vuelos;
}

int comp_numeros(int v1, int v2){
	if(v1 > v2){
		return 1;
	}
	if(v2 > v1){
		return -1;
	}
	return 0;
}

int comparador_de_n_de_vuelos(const void* v1, const void* v2){
	vuelo_t* vuelo1 = (vuelo_t*)v1;
	vuelo_t* vuelo2 = (vuelo_t*)v2;
	return comp_numeros(atoi(vuelo1->datos_separados[0]), atoi(vuelo2->datos_separados[0]));
}

int comparador_de_prior_de_vuelos(const void* v1, const void* v2){
	vuelo_t* vuelo1 = (vuelo_t*)v1;
	vuelo_t* vuelo2 = (vuelo_t*)v2;
	return comp_numeros(atoi(vuelo1->datos_separados[5]), atoi(vuelo2->datos_separados[5]));
}

void** ordenar_lista_por_n_de_vuelo(lista_t* lista){
	void** ordenar = malloc(sizeof(void*) * N);
	size_t tam = N;
	size_t cont = 0;
	ordenar[1] = NULL;
	lista_iter_t* iter = lista_iter_crear(lista);
	vuelo_t* actual = (vuelo_t*)lista_iter_ver_actual(iter);
	if(actual){
		printf("%s\n", actual->datos_separados[0]);
	}
	/*if(actual == NULL){
		printf("%s\n", "caca");
		return false;
	}*/
	for(int i = 0; !lista_iter_al_final(iter); i++){
		if (i == tam){
			ordenar = realloc(ordenar, tam * RED * sizeof(void*));
			tam = tam * RED;
		}
		ordenar[i] = lista_iter_ver_actual(iter);
		lista_iter_avanzar(iter);
		cont++;
	}
	lista_iter_destruir(iter);
	if (ordenar[1] == NULL) return ordenar;
	heap_sort(ordenar, cont, comparador_de_n_de_vuelos);
	return ordenar;
}

size_t agregar_a_tda(void** datos, void* tda, char* condicion, int caso){
	size_t cont = 0;
	for (int i = 0; datos[i] != NULL; ++i){
		if (caso == 1){
			cola_encolar((cola_t*)tda, datos[i]);
		}
		else{
			pila_apilar((pila_t*)tda, datos[i]);
		}
		cont++;
	}
	return cont;
}

void** lista_de_vuelos_a_mostrar(lista_t** listas, char* condicion, int n){
	void* tda;
	int caso = 0;
	size_t cantidad;
	if (strcmp(condicion, "asc") == 0){
		tda = (void*)cola_crear();
		caso = 1;
	}else{
		tda = (void*)pila_crear();
		caso = -1;
	}
	for (int i = 0; listas[i] != NULL && i < n; ++i){
		void** ordenados = ordenar_lista_por_n_de_vuelo(listas[i]);
		cantidad = agregar_a_tda(ordenados, tda, condicion, caso);
		free(ordenados);
	}
	void** list_a_mostr = malloc(sizeof(void*) * cantidad);
	if (caso == 1){
		cola_t* cola = (cola_t*)tda;
		for (int i = 0; !cola_esta_vacia(cola) && i < n; ++i){
			list_a_mostr[i] = cola_desencolar(cola);
		}
		cola_destruir(cola, NULL);
	}else{
		pila_t* pila = (pila_t*)tda;
		for (int i = 0; !pila_esta_vacia(pila) && i < n; ++i){
			list_a_mostr[i] = pila_desapilar(pila);
		}
		pila_destruir(pila);
	}
	return list_a_mostr;
}

bool char_isdigit_pos(const char* cad){
	for (int i = 0; cad[i] != '\0'; ++i){
		if(isdigit(cad[i])==0){
			return false;
		} 
	}
	return true;
}

bool ver_tablero(char* _cant, char* condicion, char* principo, char* fin, vuelos_t* vuelos){
	if (!char_isdigit_pos(_cant)) return false;
	int cant = atoi(_cant);
	if (cant == 0) return false;
	printf("%s\n", "cant != 0");
	printf("%s\n", condicion);
	if (strcmp(condicion, "asc") != 0 && strcmp(condicion, "desc") != 0) return false;
	printf("%s\n", "asc / desc");
	if (strcmp(principo, fin) > 0) return false;
	printf("%s\n", "principio < fin");
	lista_t** listas = (lista_t**)abb_busc_iter_corte(vuelos->arbol, principo, fin);
	if (listas == NULL){
		free(listas);
		return false;
	}
	void** list_a_mostr = lista_de_vuelos_a_mostrar(listas, condicion, cant);
	for(int i = 0; i < cant; i++){
		char** datos_vuelo = ((vuelo_t*)list_a_mostr[i])->datos_separados;
		printf("%s - %s \n", datos_vuelo[6], datos_vuelo[0]);
	}
	free(listas);
	free((lista_t**)list_a_mostr);
	return true;
}

bool info_vuelo(const char* cod_vuelo, vuelos_t* vuelos){
	vuelo_t* vuelo = hash_obtener((hash_t* const)vuelos->hash, cod_vuelo);
	if (vuelo == NULL) return false;
	char* cad = join(vuelo->datos_separados, ' ');
	printf("%s\n", cad);
	return true;
}

bool prioridad_vuelos(int cant, vuelos_t* vuelos){
	heap_t* heap = heap_crear(comparador_de_prior_de_vuelos);
	if (heap == NULL) return false;
	hash_iter_t* iter = hash_iter_crear(vuelos->hash);
	while(!hash_iter_al_final(iter)){
		const char* clave = hash_iter_ver_actual(iter);
		bool salio = heap_encolar(heap, (void*)hash_obtener(vuelos->hash, clave));
		if (!salio){
			heap_destruir(heap, NULL);
			hash_iter_destruir(iter);
			return false;
		}
		hash_iter_avanzar(iter);
	}
	vuelo_t* actual = (vuelo_t*)heap_desencolar(heap);
	heap_t* heap_n_vuelos = heap_crear(comparador_de_prior_de_vuelos);
	heap_encolar(heap_n_vuelos, actual);
	for (int i = 1; i < cant && !heap_esta_vacio(heap); ++i){
		vuelo_t* vuelo = (vuelo_t*)heap_desencolar(heap);
		if(atoi(vuelo->datos_separados[5]) == atoi(actual->datos_separados[5])){
			heap_encolar(heap_n_vuelos, vuelo);
		}
		else{
			while(!heap_esta_vacio(heap_n_vuelos)){
				actual = heap_desencolar(heap_n_vuelos);
				printf("%s - %s\n", actual->datos_separados[5], actual->datos_separados[0]);
			}
			actual = vuelo;
			heap_encolar(heap_n_vuelos, actual);
		}
	}
	heap_destruir(heap, NULL);
	heap_destruir(heap_n_vuelos, NULL);
	return true;
}

bool vuelos_borrar(const char* desde, const char* hasta, vuelos_t* vuelos){
	if (strcmp(desde, hasta) > 0) return false;
	void** listas = abb_busc_iter_corte(vuelos->arbol, desde, hasta);
	if (listas == NULL){
		free(listas);
		return false;
	}
	for (int i = 0; listas[i] != NULL ; ++i){
		lista_iter_t* iter = lista_iter_crear(listas[i]);
		if (iter == NULL) continue;
		vuelo_t* fly = lista_ver_primero(listas[i]);
		abb_borrar(vuelos->arbol, fly->datos_separados[6]);
		while(!lista_iter_al_final(iter)){
			vuelo_t* vuelo = (vuelo_t*)lista_iter_ver_actual(iter);
			hash_borrar(vuelos->hash, vuelo->datos_separados[0]);
			char* vuelo_p = join(vuelo->datos_separados, ' ');
			printf("%s\n", vuelo_p);
			vuelo_destruir(vuelo);
			lista_iter_avanzar(iter);
		}
		lista_iter_destruir(iter);
		lista_destruir(listas[i], NULL);
	}
	free(listas);
	return true;
}

int main(){
	char* linea = NULL;
	size_t cap = 0;
	vuelos_t* vuelos = crear_vuelos();
	while(getline(&linea, &cap, stdin) != -1){
		char** comando = split(linea, ' ');
		if (strcmp(comando[0], "agregar_archivo") == 0){
			if (comando[1] == NULL || comando[2] != NULL){
				print_error("agregar_archivo");
				continue;
			}
			size_t largo = strlen(comando[1]);
			comando[1][largo-1]='\0';
			printf("%s\n", comando[1]);
			bool salio = agregar_archivo(comando[1], vuelos);
			print_error_o_OK(salio, "agregar_archivo");
			continue;
		}
		if (strcmp(comando[0], "ver_tablero") == 0){
			for (int i = 0; i < 5; ++i){
				if (comando[i] == NULL){
					print_error("ver_tablero");
					continue;
				}
			}
			if (comando[5] != NULL){
				print_error("ver_tablero");
				continue;
			}
			size_t largo = strlen(comando[4]);
			comando[4][largo-1]='\0';
			bool salio = ver_tablero(comando[1],comando[2], comando[3], comando[4], vuelos);
			print_error_o_OK(salio, "ver_tablero");
			continue;

		}
		if (strcmp(comando[0], "info_vuelo") == 0){
			if (comando[1] == NULL || comando[2] != NULL){
				print_error("info_vuelo");
				continue;
			}
			size_t largo = strlen(comando[1]);
			comando[1][largo-1]='\0';
			bool salio = info_vuelo(comando[1], vuelos);
			print_error_o_OK(salio, "info_vuelo");
			continue;
		}
		if (strcmp(comando[0], "prioridad_vuelos") == 0){
			if (comando[1] == NULL || comando[2] != NULL){
				print_error("prioridad_vuelos");
				continue;
			}
			bool salio = prioridad_vuelos(atoi(comando[1]), vuelos);
			print_error_o_OK(salio, "prioridad_vuelos");
			continue;
		}
		if (strcmp(comando[0], "borrar") == 0){
			if (comando[1] == NULL || comando[2] == NULL || comando[3] != NULL){
				print_error("borrar");
				continue;
			}
			bool salio = vuelos_borrar(comando[1], comando[2], vuelos);
			print_error_o_OK(salio, "borrar");
			continue;
		}
	}
	return 0;
}
