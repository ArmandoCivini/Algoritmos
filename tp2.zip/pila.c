#include "pila.h"
#include <stdlib.h>
#include <stdio.h>

/* Definición del struct pila proporcionado por la cátedra.
 */
struct pila {
    void** datos;
    size_t cantidad;  // Cantidad de elementos almacenados.
    size_t capacidad;  // Capacidad del arreglo 'datos'.
};

/* *****************************************************************
 *                    PRIMITIVAS DE LA PILA
 * *****************************************************************/
pila_t* pila_crear(void){
	pila_t* pila = malloc(sizeof(pila_t));
	if(pila == NULL){
		return NULL;
	}
	pila->datos=malloc(sizeof(void**) * 8);
	if (pila->datos == NULL){
		return NULL;
	}
	pila->cantidad=0;
	pila->capacidad=8;
	return pila;
}


void pila_destruir(pila_t *pila){
	free(pila->datos);
	free(pila);
	pila = NULL;
}

bool pila_esta_vacia(const pila_t *pila){
	if(pila->cantidad == 0){
		return true;
	}
	return false;
}

bool pila_redimensionar(pila_t* pila, size_t tam){
	void** mem_nueva=realloc(pila->datos, sizeof(void*) * tam * pila->capacidad);		
	if (mem_nueva==NULL){
	return false;
	}
	pila->datos=mem_nueva;
	return true;
}

bool pila_apilar(pila_t* pila, void* valor){
	if (pila->cantidad == pila->capacidad){
		pila_redimensionar(pila, 2);
		pila->capacidad *= 2;
		
	}
	pila->datos[pila->cantidad] = valor;
	pila->cantidad +=1;
	return true;
}

void* pila_ver_tope(const pila_t *pila){
	if(pila->cantidad==0){
		return NULL;
	}
	size_t valor = (pila->cantidad)-1;
	return pila->datos[valor];
}

void* pila_desapilar(pila_t *pila){
	void* valor;
	size_t tam = (pila->capacidad*sizeof(void*))/2;
	if(pila->cantidad==0){
		return NULL;
	}
	if(pila->cantidad < (pila->capacidad)/4 && pila->capacidad > 8){
		pila_redimensionar(pila, tam);
		pila->capacidad /= 2;
	}
	valor=pila->datos[pila->cantidad-1];
	pila->cantidad -=1;
	return valor;
}
// ...
