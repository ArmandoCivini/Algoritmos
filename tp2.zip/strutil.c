#define _GNU_SOURCE
#include "strutil.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>


char *substr(const char *str, size_t n){
	char* str_n = malloc(sizeof(char*)*(n+1));
	if (!str_n || !str){
		return NULL;
	}
	if(n>strlen(str)){
		n = strlen(str);
	}
	for (int i = 0; i < n; ++i)
	{
		str_n[i] = str[i];
	}
	str_n[n]='\0';
	return (char*) str_n;
}

char **split(const char *str, char sep){
	char** conjunto_s;
	int guardados = 0;
	int letras_guardadas=0;
	size_t cont = 0;
	for (size_t i = 0; i < strlen(str); ++i){
		if(str[i]==sep){
			cont++;
		}
	}
	conjunto_s = malloc(sizeof(char*)*(cont+2));
	if(!conjunto_s){return NULL;} 
	for (int i = 0; i < strlen(str)+1; ++i){
		if(str[i]==sep || i==strlen(str)){			
			conjunto_s[guardados] = substr(str+letras_guardadas, (size_t)abs(i-letras_guardadas));
			letras_guardadas = i+1;
			guardados++;
		}
	}
	if(guardados == 0){
		char* a_entregar = malloc(sizeof(char*) * strlen(str));
		if(!a_entregar){return NULL;} 
		strcpy(a_entregar, str);
		conjunto_s[0] = a_entregar;
		conjunto_s[1] = NULL;
		return conjunto_s;
	}
	conjunto_s[guardados] = NULL;

	return conjunto_s;
}

char *join(char **strv, char sep){
	size_t cantidad_de_letras = 0;
	size_t cont = 0;
	size_t largo_palabra;
	while(strv[cont] != NULL){
		cont++;
	}
	size_t* largos = malloc(sizeof(char*)* (cont+1));
	cont = 0;
	while (strv[cont] != NULL)
	{
		largo_palabra = strlen(strv[cont]);
		largos[cont] = largo_palabra;
		cantidad_de_letras += largo_palabra+1;
		cont++;
	}
	largos[cont] = 0;
	cantidad_de_letras += 1;
	char* palabra = malloc(sizeof(char) * (cantidad_de_letras+(cont)));
	if(!palabra){
		free(largos);
		return NULL;
	}
	largo_palabra = 0; 
	palabra[0] = '\0';		
	for(int j = 0; j < cont; ++j){
		strcpy(palabra+largo_palabra, strv[j]);
		if(j+1 == cont){
			break;
		}
		largo_palabra += largos[j];
		palabra[largo_palabra] = sep;
		if(sep != '\0'){
			largo_palabra++;
		}	
			
	}
	free(largos);
	return palabra;
}

void free_strv(char *strv[]){
	for (int i = 0; strv[i]!=NULL; ++i)
	{
		free(strv[i]);
	}
	free(strv);
}
