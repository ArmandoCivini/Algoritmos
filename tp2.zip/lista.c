#include "lista.h"
#include <stdlib.h>
#include <stdio.h>

/****************************************
				ESTRUCTURAS
****************************************/
typedef struct nodo{
	void* valor;
	struct nodo* prox;
} nodo_t;

struct lista{
	nodo_t* primero;
	nodo_t* ultimo;
	size_t cantidad;
};

struct lista_iter{
	lista_t* lista;
	nodo_t* posicion;
	nodo_t* anterior;
};

/****************************************
		PRIMITIVAS DE LA LISTA
****************************************/
lista_t* lista_crear(){
	lista_t* lista = malloc(sizeof(lista_t));
	if(lista==NULL){
		return NULL;
	}
	lista->primero=NULL;
	lista->ultimo=NULL;
	lista->cantidad=0;
	return lista;
}

bool lista_esta_vacia(const lista_t* lista){
	return lista->cantidad==0;
}

nodo_t* nodo_crear_l(void* dato){
	nodo_t* nodo = malloc(sizeof(nodo_t));
	if(nodo==NULL){
		return NULL;
	}
	nodo->valor = dato;
	nodo->prox=NULL;
	return nodo;
}

bool lista_insertar_primero(lista_t* lista, void* dato){
	nodo_t* nodo = nodo_crear_l(dato);
	if (nodo==NULL){
		return false;
	}
	if(lista_esta_vacia(lista)){
		lista->ultimo=nodo;
	}
	nodo->prox=lista->primero;
	lista->primero = nodo;
	lista->cantidad++;
	return true;
}

bool lista_insertar_ultimo(lista_t* lista, void* dato){
	nodo_t* nodo = nodo_crear_l(dato);
	if (nodo==NULL)
	{
		return false;
	}
	if(lista_esta_vacia(lista)){
		lista->primero = nodo;
	}else{
		lista->ultimo->prox = nodo;
	}
	lista->ultimo = nodo;
	lista->cantidad++;
	return true;
}

void* lista_borrar_primero(lista_t* lista){
	if(lista_esta_vacia(lista)){
		return NULL;
	}
	nodo_t* prim_viejo = lista->primero;
	void* dato = prim_viejo->valor;
	lista->primero = prim_viejo->prox;
	if(lista->primero==NULL){
		lista->ultimo=NULL;
	}
	free(prim_viejo);
	lista->cantidad--;
	return dato;
}

void* lista_ver_primero(const lista_t* lista){
	if(lista_esta_vacia(lista)){
		return NULL;
	}
	return lista->primero->valor;
}

void* lista_ver_ultimo(const lista_t* lista){
	if(lista_esta_vacia(lista)){
		return NULL;
	}
	return lista->ultimo->valor;
}


size_t lista_largo(const lista_t* lista){
	return lista->cantidad;
}

void lista_destruir(lista_t* lista, void destruir_dato(void*)){
	while(!lista_esta_vacia(lista)){
		void* dato = lista_borrar_primero(lista);
		if(destruir_dato!=NULL){
			destruir_dato(dato);
		}
	}
	free(lista);
}

/****************************************
		PRIMITIVAS DEL ITERADOR
****************************************/
lista_iter_t* lista_iter_crear(lista_t* lista){
	lista_iter_t* iter = malloc(sizeof(lista_iter_t));
	if(iter == NULL){
		return NULL;
	}
	iter->posicion = lista->primero;
	iter->anterior = NULL;
	iter->lista = lista;
	return iter;
}

bool lista_iter_avanzar(lista_iter_t* iter){
	if(lista_iter_al_final(iter)){
		return false;
	}
	nodo_t* anterior = iter->posicion;
	iter->posicion = anterior->prox;
	iter->anterior = anterior;
	return true;
}

void* lista_iter_ver_actual(const lista_iter_t *iter){
	if(iter->posicion==NULL){
		return NULL;
	}
	return iter->posicion->valor;
}

bool lista_iter_al_final(const lista_iter_t *iter){
	return iter->posicion == NULL;
}

void lista_iter_destruir(lista_iter_t *iter){
	free(iter);
}

bool lista_iter_insertar(lista_iter_t *iter, void *dato){
	nodo_t* nodo = nodo_crear_l(dato);
	if (nodo==NULL){
		return false;
	}
	nodo->prox=iter->posicion;
	iter->posicion=nodo;
	iter->lista->cantidad++;
	if(iter->anterior == NULL){		
		iter->lista->primero = nodo;
	}else{
		iter->anterior->prox=nodo;
	}
	if(nodo->prox == NULL){
		iter->lista->ultimo = nodo; 
	}
	return true;
}

void* lista_iter_borrar(lista_iter_t* iter){
	if(lista_iter_al_final(iter)){
		return NULL;
	}
	iter->lista->cantidad--;
	nodo_t* a_borrar=iter->posicion;
	void* dato= a_borrar->valor;
	iter->posicion = a_borrar->prox;
	if(iter->posicion == NULL){
		iter->lista->ultimo = iter->anterior;
	}
	if(iter->anterior == NULL){
		iter->lista->primero = iter->posicion;
	}else{
		iter->anterior->prox = iter->posicion;
	}
	free(a_borrar);
	return dato;
}

void lista_iterar(lista_t* lista, bool visitar(void* dato, void* extra), void* extra){
	nodo_t* posicion = lista->primero;
	while(posicion!=NULL){
		if(visitar!=NULL){
			bool resultado = visitar(posicion->valor, extra);
			if(resultado==false){
				break;
			}
		}
		posicion = posicion->prox;
	}
}