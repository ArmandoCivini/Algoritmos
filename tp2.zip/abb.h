#ifndef ABB_H
#define ABB_H
#include <stdbool.h>
#include <stdlib.h>

/******************
	ESTRUCTURAS
******************/

/*Estructura Del TDA que cumple a propiedad de arbol binario de busqueda*/
typedef struct abb abb_t; 

/*Tipo utilizado para iterar manualmente el abb*/
typedef struct abb_iter abb_iter_t;

/*Prototipo de funcion de comparacion para el TDA 
Devulve 0 si ambas strings son iguales 
Devulve un int 0 > si la string de la izquierda es mayor a la derecha
Devulve un int 0 < si la string de la izquierda es menor a la derecha*/
typedef int (*abb_comparar_clave_t) (const char *, const char *);

/*Proto tipo de funcion que libera la porcion de memoria del dato pasado*/
typedef void (*abb_destruir_dato_t) (void *);

/************************
	PRIMITIVAS DEL ABB
************************/
// Crea el arbol binario de busqueda
// Pre: debe recibir una funcion de comparacion de strings y, si es necesario, una funcion de liberacion de memoria.
// Post: Devulve un arbol binario de busqueda vacio 
abb_t* abb_crear(abb_comparar_clave_t cmp, abb_destruir_dato_t destruir_dato);

// Guarda punteros en el abb y los organiza dependiendo de la clave y la funcion de comparacion del abb
// si la clave ya se encuentra en el abb remplaza el valor
// Pre: el abb fue creado
// Post: Devulve true si el elemento se guardo correctamente;  
bool abb_guardar(abb_t* arbol, const char* clave, void* dato);

// Devulve el valor asociado a la clave, si no existe tal valor devulve NULL
// Pre: el abb fue creado
// Post: devulve el valor o NULL
void* abb_obtener(const abb_t* arbol, const char* clave);

// Pre: el abb fue creado
// Post: devulve true si se encuentra la clave, de lo contrario devulve false
bool abb_pertenece(const abb_t* arbol, const char* clave);

// Pre: el abb fue creado
// Post: devulve el valor asociado a la clave borrada o NULL si no se encontro la clave
void* abb_borrar(abb_t* arbol, const char* clave);


// Pre: se creo el abb
// Post: devuleve la cantidad de elementos en el abb
size_t abb_cantidad(abb_t* arbol);

// Pre: el abb fue creado
// Post: el abb y todos sus elementos restantesfueron destruidos
void abb_destruir(abb_t* arbol);

/****************************
	PRIMITIVAS DEL ITERADOR
*****************************/

// Pre: el abb fue creado
// Post: crea el iteradr y lo posicion ene el elemento mas a la izquierda
abb_iter_t *abb_iter_in_crear(const abb_t *arbol);

// avanza de manera inorder(izq -> padre -> der)
// Pre: el iterador fue creado
// Post: devulve true si avanzo sin problema de lo contrario devulve false
bool abb_iter_in_avanzar(abb_iter_t *iter);


// Pre: el iterador fue creado
// Post: devuelve true si el iterador esta al final del arbol(actual == NULL) de lo contrario devulve false
bool abb_iter_in_al_final(const abb_iter_t *iter);


// Pre: el iterador fue creado
// Post: devuleve la clave de la posicion actual del iterador
const char *abb_iter_in_ver_actual(const abb_iter_t *iter);

// Pre: el iterador fue creado
// Post: Se libero la memoria del iterador
void abb_iter_in_destruir(abb_iter_t* iter);

// Pre: El iterador fue creado
// Post: Para cada elemento del abb se llamo la funcion visistar que se pasa como parametro
// si visitar resulta en false se para la iteracion.
void abb_in_order(abb_t* abb, bool visitar(const char*, void*, void*), void* extra);

void** abb_busc_iter_corte(abb_t* arbol, const char* clave_busc, const char* clave_corte);

#endif //LISTA_H
