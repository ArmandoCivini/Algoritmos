#include "cola.h"
#include <stdlib.h>


typedef struct nodo{
	void* valor;
	struct nodo* prox;
} nodo_t; 

struct cola{
	nodo_t* primero;
	nodo_t* ultimo;
};

nodo_t* nodo_crear_c(void* dato){
	nodo_t* nodo = malloc(sizeof(nodo_t));
	if(nodo==NULL){
		return NULL;
	}
	nodo->valor = dato;
	nodo->prox = NULL;
	return nodo;
}

cola_t* cola_crear(){
	cola_t* cola = malloc(sizeof(cola_t));
	cola->primero=NULL;
	cola->ultimo=NULL;
	if(cola==NULL){
		return NULL;
	}
	return cola;
}

bool cola_esta_vacia(const cola_t *cola){
	if(cola->primero==NULL && cola->ultimo==NULL){
		return true;
	}
	return false;
}

void* cola_ver_primero(const cola_t *cola){
	if(cola_esta_vacia(cola)){
		return NULL;
	}
	return cola->primero->valor;
}


void* cola_desencolar(cola_t* cola){
	if (cola_esta_vacia(cola)){
		return NULL;
	}
	nodo_t* prim_viejo = cola->primero;
	cola->primero= prim_viejo->prox;
	if(cola->primero==NULL){
		cola->ultimo=NULL;
	}
	void* dato = (prim_viejo->valor);
	free(prim_viejo);
	return dato;
}

bool cola_encolar(cola_t* cola, void* valor){
	nodo_t* nuevo_nodo = nodo_crear_c(valor);
	if(nuevo_nodo==NULL){
		return false;
	}
	if(cola_esta_vacia(cola)){
		cola->primero=nuevo_nodo;
	}else{
		cola->ultimo->prox = nuevo_nodo;
	}
	cola->ultimo = nuevo_nodo;
	return true;
}

void cola_destruir(cola_t *cola, void destruir_dato(void*)){
	while(!cola_esta_vacia(cola)){
		void* dato = cola_desencolar(cola);
		if(destruir_dato!=NULL){
			destruir_dato(dato);	
		}
		
	}
	free(cola);
}

