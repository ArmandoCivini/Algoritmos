#ifndef _LISTA_H
#define _LISTA_H

#include <stdlib.h>
#include <stdbool.h>

/****************************************
	DEFINICION DE TIPOS DE DATOS
****************************************/
struct lista;
typedef struct lista lista_t;
typedef struct lista_iter lista_iter_t;

/****************************************
		PRIMITIVAS DE LA LISTA
****************************************/
// Crea la lista
// Post: Devulve una lista vacia
lista_t *lista_crear(void);

//Devulve true si la lista no tiene elemntos
//pre: La lista fue creada
bool lista_esta_vacia(const lista_t* lista);

/*Inserta el elemento pasado como parametro en el principio de la lista
y devulve true si lo inserta correctamnte de lo contrario devulve false*/
//Pre : La lista fue creada
//Post : el primer elemento de la lista es el dato pasado por parametro
bool lista_insertar_primero(lista_t* lista, void* dato);

/*Inserta el elemento pasado como parametro en el final de la lista
y devulve true si lo inserta correctamnte de lo contrario devulve false*/
//Pre : La lista fue creada
//Post : el ultimo elemento de la lista es el dato pasado por parametro
bool lista_insertar_ultimo(lista_t* lista, void* dato);

/*Saca el primer elemento de la lista y lo devulve, 
el que lo seguia es el nuevo primero. Si la lista estaba vacia devuelve NULL*/
//Pre: La lista fue creada
/*Post: se devolvio el primer elemento de la lista y la posicion de todos los 
elemntos se reduce en 1 o deulve NULL si hubo un error*/
void* lista_borrar_primero(lista_t* lista);

//Devulve el valor del primer elemento de la lista
//Pre: la lista fue creada
void* lista_ver_primero(const lista_t* lista);

//Devuleve el valor del ultimo elemento de la lista
//Pre: la lista fue creada
void* lista_ver_ultimo(const lista_t* lista);

//Devulve cuantos elementos hay en la lista
//Pre: la lista fue creada
size_t lista_largo(const lista_t* lista);

/*Destruye la lista y todos sus elementos, 
es necesario pasar comoparametro una funcion para destruir datos*/
/*Pre: la lista fue creada, destruir_dato es una función capaz de destruir
los datos de la cola, o NULL en caso de que no se la utilice.*/
//Post la lista fue destruida
void lista_destruir(lista_t* lista, void destruir_dato(void*));

/****************************************
		PRIMITIVAS DEL ITERADOR
****************************************/
//Crea el interador de la lista
//Pre: hay una lista creada
//Post: se creo el iterador de la lista
lista_iter_t *lista_iter_crear(lista_t *lista);

//Avanza una posicion de la lista, si la lista esta vacia, o llega al final de la lista, devuelve false.
//Pre: El iterador y la lista fueron creados
//Post: El iterador esta en la siguiente posicion de la lista
bool lista_iter_avanzar(lista_iter_t *iter);

//Devuelve el valor de la posicion actual
//Pre: el iterador y la lista fueron creados
//Post: se devolvio el elemento de la posicion actual si la lista no esta vacia
void* lista_iter_ver_actual(const lista_iter_t *iter);

//Devulve true si la posicion del iterador llego al final de la lista
//Pre: El iterador fue creado
//Post: Devulve true si el iterador esta en el ultimo elemento de la lista
bool lista_iter_al_final(const lista_iter_t *iter);

//Destruye el iterador pero deja la lista intacta.
//Pre: el iterador fue creado
//post el iterador fue destruido
void lista_iter_destruir(lista_iter_t *iter);

/*inserta el dato en la posicion actual y "empuja" el elemento que solia estar en esa posicion y 
sus siguientes hacia el costado, devulve true si lo inserta sin problemas, false de lo contrario*/
//Pre: El iterador fue creado
//Post: se agrego el dato a la lista y se movieron todos los datos siguientes a este una posicion
bool lista_iter_insertar(lista_iter_t *iter, void *dato);

//Borra el elemento de la lista de la posicion actual del iterador y lo devulve, la lista esta vacia devulve NULL
//Pre: El iterador fue creado
//Post: Devulve el valor del elemento de la lista de la posicion actual dell iterador y lo borrra de la lista
// devulve NULL si la lista esta vacia
void* lista_iter_borrar(lista_iter_t *iter);

/*Itera la lista y apilica la funcion pasada como paramentro a cada elemento de la lista,
se puede pasar un parametro extra el que tambien es parametro de la funcion "visitar"*/
//Pre: la lista fue creada
//Post: Se le aplico la funcion "visitar" a todos los elementos posibles
void lista_iterar(lista_t* lista, bool visitar(void* dato, void* extra), void* extra);


#endif // _LISTA_H
